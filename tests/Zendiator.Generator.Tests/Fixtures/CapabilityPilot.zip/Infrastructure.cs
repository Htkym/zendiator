using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading.Tasks.Sources;

namespace S07Pilot;

public sealed class Probe
{
    public bool Recording;
    public readonly List<string> Trace = [];
    public readonly List<string> Created = [];
    public readonly List<string> Disposed = [];
    public readonly List<object> Requests = [];
    public readonly List<CancellationToken> Tokens = [];
    public readonly List<Zendiator.SendExitInfo> Exits = [];
    public void Hit(string phase, object request, CancellationToken token)
    {
        if (!Recording) return;
        Trace.Add(phase); Requests.Add(request); Tokens.Add(token);
    }
    public void Final(string id, object request, Zendiator.SendExitInfo exit, CancellationToken token)
    {
        Hit(id + ".finally", request, token);
        if (Recording) Exits.Add(exit);
    }
}

// Exactly one operation at a time. Completion is queued only after the real await
// continuation has registered. Validation additionally controls the release itself.
public sealed class PendingSource : IValueTaskSource<int>, IDisposable
{
    private ManualResetValueTaskSourceCore<int> _core = new() { RunContinuationsAsynchronously = true };
    private readonly ManualResetEventSlim _idle = new(true);
    private readonly AutoResetEvent _work = new(false);
    private Thread? _worker;
    private bool _disposed, _stop;
    private int _active;
    private int _value;
    public bool Automatic = true;
    public TaskCompletionSource? Registered;
    public long Preparations, Registrations, Completions, Consumptions;
    public ValueTask<int> Prepare(int value)
    {
        Drain(); // Do not reset the reusable source before the preceding worker finishes.
        if (Interlocked.CompareExchange(ref _active, 1, 0) != 0) throw new InvalidOperationException("Concurrent source reuse");
        _core.Reset(); _value = value; Interlocked.Increment(ref Preparations);
        if (!Automatic) Registered = new(TaskCreationOptions.RunContinuationsAsynchronously);
        return new(this, _core.Version);
    }
    public ValueTaskSourceStatus GetStatus(short token) => _core.GetStatus(token);
    public void OnCompleted(Action<object?> continuation, object? state, short token, ValueTaskSourceOnCompletedFlags flags)
    {
        if (Interlocked.CompareExchange(ref _active, 2, 1) != 1) throw new InvalidOperationException("Duplicate registration");
        _core.OnCompleted(continuation, state, token, flags);
        Interlocked.Increment(ref Registrations);
        Registered?.TrySetResult();
        if (Automatic) QueueCompletion();
    }
    public void QueueCompletion()
    {
        _idle.Reset();
        if (_worker is null) { _worker = new Thread(Work) { IsBackground = true, Name = "Zendiator pending completion" }; _worker.Start(); }
        _work.Set();
    }
    private void Work() { while (true) { _work.WaitOne(); if (_stop) return; Complete(); } }
    public void Drain() => _idle.Wait();
    public void Dispose() { if (_disposed) return; Drain(); _stop = true; _work.Set(); _worker?.Join(); _disposed = true; _work.Dispose(); _idle.Dispose(); }
    private void Complete()
    {
        if (Volatile.Read(ref _active) != 2) throw new InvalidOperationException("Completion without registered await");
        try { Interlocked.Increment(ref Completions); _core.SetResult(_value); }
        finally { _idle.Set(); } // No source work or allocation after this signal.
    }
    public int GetResult(short token)
    {
        if (Volatile.Read(ref _active) != 2) throw new InvalidOperationException("Duplicate consumption");
        var result = _core.GetResult(token);
        Interlocked.Increment(ref Consumptions);
        if (Interlocked.CompareExchange(ref _active, 0, 2) != 2) throw new InvalidOperationException("Invalid consumption state");
        return result;
    }
    public object Snapshot() => new { Preparations, Registrations, Completions, Consumptions, Active = Volatile.Read(ref _active) };
    public bool IsBalanced => Preparations == Registrations && Registrations == Completions && Completions == Consumptions && Volatile.Read(ref _active) == 0;
}

public static class Evidence
{
    public static readonly JsonSerializerOptions Json = new() { WriteIndented = true };
    public static string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path)));
    public static object EnvironmentSnapshot() => new
    {
        pid = System.Environment.ProcessId,
        processStartUtc = Process.GetCurrentProcess().StartTime.ToUniversalTime(),
        runtime = RuntimeInformation.FrameworkDescription,
        version = System.Environment.Version.ToString(),
        os = RuntimeInformation.OSDescription,
        architecture = RuntimeInformation.ProcessArchitecture.ToString(),
        affinity = (OperatingSystem.IsWindows() || OperatingSystem.IsLinux()) ? Process.GetCurrentProcess().ProcessorAffinity.ToInt64() : 0,
        gcServer = System.Runtime.GCSettings.IsServerGC,
        assembly = typeof(Evidence).Assembly.Location,
        assemblySha256 = Hash(typeof(Evidence).Assembly.Location), harnessSourceBase = "4cc3f1bb86928eb59b311453278b41cc634bdeaf", moduleVersionId = typeof(Evidence).Module.ModuleVersionId,
        runtimeSha256 = Hash(typeof(object).Assembly.Location),
        abstractionsSha256 = Hash(typeof(Zendiator.SendExitInfo).Assembly.Location),
        zendiatorSha256 = Hash(typeof(Zendiator.DependencyInjection.ZendiatorServiceResolver).Assembly.Location),
        diSha256 = Hash(typeof(Microsoft.Extensions.DependencyInjection.ServiceProvider).Assembly.Location),
        jitEnvironment = new[] { "DOTNET_TieredCompilation", "DOTNET_TieredPGO", "DOTNET_ReadyToRun", "DOTNET_TC_QuickJit", "DOTNET_TC_QuickJitForLoops", "COMPlus_TieredCompilation", "COMPlus_TieredPGO", "COMPlus_ReadyToRun" }.ToDictionary(n => n, System.Environment.GetEnvironmentVariable)
    };
    public static void Save(string path, object value)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        File.WriteAllText(path, JsonSerializer.Serialize(value, Json) + "\n");
    }
    public static void CreateOnce(string name, object value)
    {
        var dir = System.Environment.GetEnvironmentVariable("S07_CASE_DIR") ?? throw new InvalidOperationException("Missing owned case directory");
        using var file = new FileStream(Path.Combine(dir, name), FileMode.CreateNew, FileAccess.Write);
        JsonSerializer.Serialize(file, value, Json);
    }
    public static void Require(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
