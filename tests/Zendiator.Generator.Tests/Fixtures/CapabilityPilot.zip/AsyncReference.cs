using Zendiator;
using Microsoft.Extensions.DependencyInjection;
namespace S07Pilot.Async;
// Independent concrete three-scope protocol from the declared hook contract.
// No generator model, emitter text or generated source is read to build this oracle.
public sealed class Reference(IServiceProvider provider):global::S07Pilot.Async.Generated.Routes.IZendiator {
 public ValueTask<int> SendAsync(Query request,CancellationToken cancellationToken=default){
 ArgumentNullException.ThrowIfNull(request);return Execute(request,cancellationToken);
 }
 private async ValueTask<int> Execute(Query request,CancellationToken t){
 t.ThrowIfCancellationRequested();int result;
var h0=provider.GetRequiredService<H0>();var s0=request;bool ok0=false;Exception? error0=null;try{
s0=await ((global::Zendiator.IAsyncSendRequestTransform<Query>)h0).BeforeAsync(s0,t).ConfigureAwait(false);ArgumentNullException.ThrowIfNull(s0,"request");t.ThrowIfCancellationRequested();
var h1=provider.GetRequiredService<H1>();var s1=s0;bool ok1=false;Exception? error1=null;try{
s1=await ((global::Zendiator.IAsyncSendRequestTransform<Query>)h1).BeforeAsync(s1,t).ConfigureAwait(false);ArgumentNullException.ThrowIfNull(s1,"request");t.ThrowIfCancellationRequested();
var h2=provider.GetRequiredService<H2>();var s2=s1;bool ok2=false;Exception? error2=null;try{
s2=await ((global::Zendiator.IAsyncSendRequestTransform<Query>)h2).BeforeAsync(s2,t).ConfigureAwait(false);ArgumentNullException.ThrowIfNull(s2,"request");t.ThrowIfCancellationRequested();
var handler=provider.GetRequiredService<Handler>();result=await handler.HandleAsync(s2,t).ConfigureAwait(false);
result=await ((global::Zendiator.IAsyncSendResponseTransform<Query,int>)h2).AfterAsync(s2,result,t).ConfigureAwait(false);ok2=true;
}catch(Exception failure2){error2=failure2;try{await ((global::Zendiator.IAsyncSendExceptionObserver<Query>)h2).OnExceptionAsync(s2,failure2,t).ConfigureAwait(false);}catch(Exception replacement2){error2=replacement2;throw;}throw;}finally{await ((global::Zendiator.IAsyncSendFinallyObserver<Query>)h2).FinallyAsync(s2,new(ok2,error2),t).ConfigureAwait(false);}
result=await ((global::Zendiator.IAsyncSendResponseTransform<Query,int>)h1).AfterAsync(s1,result,t).ConfigureAwait(false);ok1=true;
}catch(Exception failure1){error1=failure1;try{await ((global::Zendiator.IAsyncSendExceptionObserver<Query>)h1).OnExceptionAsync(s1,failure1,t).ConfigureAwait(false);}catch(Exception replacement1){error1=replacement1;throw;}throw;}finally{await ((global::Zendiator.IAsyncSendFinallyObserver<Query>)h1).FinallyAsync(s1,new(ok1,error1),t).ConfigureAwait(false);}
result=await ((global::Zendiator.IAsyncSendResponseTransform<Query,int>)h0).AfterAsync(s0,result,t).ConfigureAwait(false);ok0=true;
}catch(Exception failure0){error0=failure0;try{await ((global::Zendiator.IAsyncSendExceptionObserver<Query>)h0).OnExceptionAsync(s0,failure0,t).ConfigureAwait(false);}catch(Exception replacement0){error0=replacement0;throw;}throw;}finally{await ((global::Zendiator.IAsyncSendFinallyObserver<Query>)h0).FinallyAsync(s0,new(ok0,error0),t).ConfigureAwait(false);}
return result;}}

