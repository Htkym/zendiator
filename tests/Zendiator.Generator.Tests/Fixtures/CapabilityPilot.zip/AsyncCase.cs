using Zendiator;
using Zendiator.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
namespace S07Pilot.Async;
public sealed record Query(int Value) : IRequest<int>;
[ZendiatorComposition("s07-async")] public sealed class Routes;
public static class Registration {
 public static IServiceCollection Add(IServiceCollection s) => s.AddZendiator<Routes>(c => {
 c.Handlers<Query>(DispatchFamily.SendAsync,typeof(Handler));
 c.Pipeline<Query>(DispatchFamily.SendAsync,Stage.Hook<H0>(),Stage.Hook<H1>(),Stage.Hook<H2>());
 });
}
public abstract class HookBase : IAsyncSendRequestTransform<Query>,IAsyncSendResponseTransform<Query,int>,IAsyncSendExceptionObserver<Query>,IAsyncSendFinallyObserver<Query>,IDisposable {
 protected readonly Probe P; private readonly string _id;
 protected HookBase(Probe p,string id){P=p;_id=id;p.Created.Add(id);}
 public ValueTask<Query> BeforeAsync(Query r,CancellationToken t){P.Hit(_id+".before",r,t);return new(r);}
 public ValueTask<int> AfterAsync(Query r,int value,CancellationToken t){P.Hit(_id+".after",r,t);return new(value+1);}
 public ValueTask OnExceptionAsync(Query r,Exception e,CancellationToken t){P.Hit(_id+".exception",r,t);return default;}
 public ValueTask FinallyAsync(Query r,SendExitInfo exit,CancellationToken t){P.Final(_id,r,exit,t);return default;}
 public void Dispose()=>P.Disposed.Add(_id);
}
public sealed class H0(Probe p):HookBase(p,"h0");
public sealed class H1(Probe p):HookBase(p,"h1");
public sealed class H2(Probe p):HookBase(p,"h2");
[ZendiatorHandler] public sealed class Handler:IRequestHandler<Query,int>,IDisposable {
 private readonly Probe _p;private readonly PendingSource _source;
 public Handler(Probe p,PendingSource source){_p=p;_source=source;p.Created.Add("handler");}
 public ValueTask<int> HandleAsync(Query r,CancellationToken t){_p.Hit("handler",r,t);return _source.Prepare(r.Value+1);}
 public void Dispose()=>_p.Disposed.Add("handler");
}

